'''
ad_engine.py
Advertisement Selection Engine that employs a Decision Network
to Maximize Expected Utility associated with different Decision
variables in a stochastic reasoning environment.
'''
import pandas as pd
from pomegranate import *
import math
import itertools
import unittest
from ad_agent_soln import AdEngine

class AdAgentGradingTests(unittest.TestCase):
    
    def test_meu_lecture_example_no_evidence(self):
        ad_engine = AdEngine('../dat/lecture5-2-data.csv', ["D"], {"Y": {0: 3, 1: 1}})
        evidence = {}
        decision = ad_engine.meu(evidence)
        self.assertAlmostEqual(2, decision[1], delta=0.01)
        self.assertEqual({"D": 0}, decision[0])
     
    def test_meu_lecture_example_with_evidence(self):
        ad_engine = AdEngine('../dat/lecture5-2-data.csv', ["D"], {"Y": {0: 3, 1: 1}})
        evidence = {"X": 0}
        decision = ad_engine.meu(evidence)
        self.assertAlmostEqual(2, decision[1], delta=0.01)
        self.assertEqual({"D": 1}, decision[0])
         
        evidence2 = {"X": 1}
        decision2 = ad_engine.meu(evidence2)
        self.assertAlmostEqual(2.4, decision2[1], delta=0.01)
        self.assertEqual({"D": 0}, decision2[0])
         
    def test_vpi_lecture_example_no_evidence(self):
        ad_engine = AdEngine('../dat/lecture5-2-data.csv', ["D"], {"Y": {0: 3, 1: 1}})
        evidence = {}
        vpi = ad_engine.vpi("X", evidence)
        self.assertAlmostEqual(0.24, vpi, delta=0.1)
     
    def test_meu_defendotron_no_evidence(self):
        ad_engine = AdEngine('../dat/adbot-data.csv', ["Ad1", "Ad2"], {"S": {0: 0, 1: 1776, 2: 500}})
        evidence = {}
        decision = ad_engine.meu(evidence)
        self.assertEqual({"Ad1": 1, "Ad2": 0}, decision[0])
        self.assertAlmostEqual(746.72, decision[1], delta=0.01)
         
    def test_meu_defendotron_with_evidence(self):
        ad_engine = AdEngine('../dat/adbot-data.csv', ["Ad1", "Ad2"], {"S": {0: 0, 1: 1776, 2: 500}})
        evidence = {"T": 1}
        decision = ad_engine.meu(evidence)
        self.assertEqual({"Ad1": 1, "Ad2": 1}, decision[0])
        self.assertAlmostEqual(720.73, decision[1], delta=0.01)
         
        evidence2 = {"T": 0, "G": 0}
        decision2 = ad_engine.meu(evidence2)
        self.assertEqual({"Ad1": 0, "Ad2": 0}, decision2[0])
        self.assertAlmostEqual(796.82, decision2[1], delta=0.01)
         
    def test_vpi_defendotron_no_evidence(self):
        ad_engine = AdEngine('../dat/adbot-data.csv', ["Ad1", "Ad2"], {"S": {0: 0, 1: 1776, 2: 500}})
        evidence = {}
        vpi = ad_engine.vpi("G", evidence)
        self.assertAlmostEqual(20.77, vpi, delta=0.1)
         
        vpi2 = ad_engine.vpi("F", evidence)
        self.assertAlmostEqual(0, vpi2, delta=0.1)
         
    def test_vpi_defendotron_with_evidence(self):
        ad_engine = AdEngine('../dat/adbot-data.csv', ["Ad1", "Ad2"], {"S": {0: 0, 1: 1776, 2: 500}})
        evidence = {"T": 0}
        vpi = ad_engine.vpi("G", evidence)
        self.assertAlmostEqual(25.49, vpi, delta=0.1)
         
        evidence2 = {"G": 1}
        vpi2 = ad_engine.vpi("P", evidence2)
        self.assertAlmostEqual(0, vpi2, delta=0.1)
         
        evidence3 = {"H": 0, "T": 1, "P": 0}
        vpi3 = ad_engine.vpi("G", evidence3)
        self.assertAlmostEqual(66.76, vpi3, delta=0.1)
         
    def test_meu_grading_no_evidence(self):
        ad_engine = AdEngine('../dat/hw2_grading.csv', ["A"], {"D": {0: 10, 1: 20, 2: 30}})
        evidence = {}
        decision = ad_engine.meu(evidence)
        self.assertAlmostEqual(23.57, decision[1], delta=0.01)
        self.assertEqual({"A": 1}, decision[0])
         
    def test_meu_grading_with_evidence(self):
        ad_engine = AdEngine('../dat/hw2_grading.csv', ["A"], {"D": {0: 10, 1: 20, 2: 30}})
        evidence = {"C": 2}
        decision = ad_engine.meu(evidence)
        self.assertAlmostEqual(12.38, decision[1], delta=0.01)
        self.assertEqual({"A": 0}, decision[0])
        
    def test_vpi_grading_no_evidence(self):
        ad_engine = AdEngine('../dat/hw2_grading.csv', ["A"], {"D": {0: 10, 1: 20, 2: 30}})
        evidence = {}
        decision = ad_engine.meu(evidence)
        vpi = ad_engine.vpi("B", evidence)
        self.assertAlmostEqual(1.66, vpi, delta=0.1)
        
        vpi2 = ad_engine.vpi("C", evidence)
        self.assertAlmostEqual(0, vpi2, delta=0.1)
        
    def test_vpi_grading_with_evidence(self):
        ad_engine = AdEngine('../dat/hw2_grading.csv', ["A"], {"D": {0: 10, 1: 20, 2: 30}})
        evidence = {"B": 0}
        decision = ad_engine.meu(evidence)
        vpi = ad_engine.vpi("C", evidence)
        self.assertAlmostEqual(0, vpi, delta=0.1)
        
if __name__ == '__main__':
    unittest.main()

