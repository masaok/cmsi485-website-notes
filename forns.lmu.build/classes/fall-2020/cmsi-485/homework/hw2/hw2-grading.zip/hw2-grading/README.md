== HW 2 Grading Instructions ==
1. Copy the attached grading dataset into your project's /dat/ directory
2. Run the attached grading_tests.py from your project's /src/ directory
